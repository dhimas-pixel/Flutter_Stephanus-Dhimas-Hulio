import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF58A9BF);
const kPrimaryLightColor = Color(0xFFD8FFFF);
