enum StateType { loading, error, success }
